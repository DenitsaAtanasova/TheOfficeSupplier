﻿Imports System.Data

Partial Class XML_Product
    Inherits System.Web.UI.Page

    Dim strSupplierID As Object
    Dim strCategoryID As Object
    Dim txtQuabtityPerUnit As Object

    Protected Sub Page_Load(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            BindGrid()
        End If
    End Sub

    Sub BindGrid()
        Dim oDs As New DataSet
        oDs.ReadXml(Request.PhysicalApplicationPath + "product.xml")
        GridView1.DataSource = oDs
        GridView1.DataBind()

    End Sub

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, _
         ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) _
         Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Protected Sub GridView1_RowDeleting(ByVal sender As Object, _
       ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) _
       Handles GridView1.RowDeleting
        BindGrid()
        Dim oDs As DataSet = GridView1.DataSource
        oDs.Tables(0).Rows(GridView1.Rows(e.RowIndex).DataItemIndex).Delete()
        oDs.WriteXml(Request.PhysicalApplicationPath + "product.xml")
        BindGrid()
    End Sub

    Protected Sub GridView1_RowEditing(ByVal sender As Object, _
        ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) _
        Handles GridView1.RowEditing
        GridView1.EditIndex = e.NewEditIndex
        BindGrid()
    End Sub

    Protected Sub GridView1_RowCancelingEdit(ByVal sender As Object, _
       ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) _
       Handles GridView1.RowCancelingEdit
        GridView1.EditIndex = -1
        BindGrid()
    End Sub

    Protected Sub GridView1_RowUpdating(ByVal sender As Object, _
         ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) _
         Handles GridView1.RowUpdating
        ' Get the new values from the GridView controls
        Dim i As Integer = GridView1.Rows(e.RowIndex).DataItemIndex
        Dim strId As String = CType(GridView1.Rows(e.RowIndex).Cells(2).Controls(0), TextBox).Text
        Dim strName As String = CType(GridView1.Rows(e.RowIndex).Cells(3).Controls(0), TextBox).Text
        Dim strTel As String = CType(GridView1.Rows(e.RowIndex).Cells(4).Controls(0), TextBox).Text
        Dim strQuantity As String = CType(GridView1.Rows(e.RowIndex).Cells(5).Controls(0), TextBox).Text
        GridView1.EditIndex = -1
        BindGrid()
        ' Update the XML file using the new values

        Dim oDs As DataSet = GridView1.DataSource
        oDs.Tables(0).Rows(i).Item(0) = StrProductName()
        oDs.Tables(0).Rows(i).Item(1) = strSupplierID
        oDs.Tables(0).Rows(i).Item(2) = strCategoryID
        oDs.Tables(0).Rows(i).Item(2) = strQuantity
        oDs.WriteXml(Request.PhysicalApplicationPath + "product.xml")
        BindGrid()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, _
           ByVal e As System.EventArgs) Handles Button1.Click
        BindGrid()
        Dim oDs As DataSet = GridView1.DataSource
        Dim oDr As DataRow = oDs.Tables(0).NewRow
        oDr("ProductName") = txtProductName.Text
        oDr("SupplierID") = txtSupplierID.Text
        oDr("CategoryID") = txtCategoryID.Text
        oDr("QuantityPerUnit") = txtQuantityPerUnit.Text
        oDs.Tables(0).Rows.Add(oDr)
        oDs.WriteXml(Request.PhysicalApplicationPath + "product.xml")
        BindGrid()
    End Sub

    Private Function StrProductName() As Object
        Throw New NotImplementedException
    End Function

End Class

