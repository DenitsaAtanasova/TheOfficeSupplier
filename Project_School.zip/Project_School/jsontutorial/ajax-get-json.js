{ 
    "menu": "Books", 
    "commands": [ 
        {
            "title": "Harry Potter", 
            "author":"JK Rowling"
        }, 
        {
            "title": "Dont Go!", 
            "author": "James Woods"
        }, 
        {
            "title": "Born in the USA",
            "author": "Bruce Springsteen"
        }
    ] 
}

